// shared.js — logic shared between the background service worker (live
// checks on navigation) and the popup (on-demand checks / fallback).
//
// Loaded as a classic script (not an ES module) via <script> in popup.html
// and importScripts() in background.js, so everything here attaches to the
// global scope (window in the popup, self in the service worker) — same
// pattern as libs/psl.js.

const DOH_ENDPOINT = "https://cloudflare-dns.com/dns-query";
const VERSION_TAG = "v=FORSALE1;";
const KNOWN_TAGS = { fcod: "Code", ftxt: "Text", furi: "URI", fval: "Asking price" };
const TAG_PRIORITY = ["furi", "fval", "ftxt", "fcod"];

// How long a per-domain lookup result is considered fresh. Avoids hitting
// the DoH resolver again every time the user revisits the same site within
// a browsing session. Cleared entirely when the browser closes, since it
// lives in chrome.storage.session.
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes

// A navigation's URL chain (see background.js) has at most 2 entries —
// where it started, where it landed — so this cap is really just a safety
// bound, not a meaningful tuning knob.
const MAX_CHAIN_DOMAINS = 2;

function getRegistrableDomain(hostname) {
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(hostname) || hostname.includes(":")) return null; // IPv4 / IPv6 literal
  if (hostname === "localhost") return null;
  const parsed = psl.parse(hostname);
  return parsed.domain || null; // null if the TLD isn't in the Public Suffix List
}

async function lookupTXT(name) {
  const url = `${DOH_ENDPOINT}?name=${encodeURIComponent(name)}&type=TXT`;
  const response = await fetch(url, { headers: { Accept: "application/dns-json" } });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);

  const data = await response.json();
  if (!data.Answer) return [];

  return data.Answer
    .filter((a) => a.type === 16) // TXT
    .map((a) => unquoteTXT(a.data));
}

// DoH-as-JSON returns TXT RDATA as a quoted string using DNS
// presentation-format escaping (RFC 1035 §5.1): printable ASCII passes
// through as-is, `\"` and `\\` escape themselves, and every other byte —
// notably each byte of a multi-byte UTF-8 sequence — is escaped
// individually as `\DDD` (three decimal digits), e.g.
//   "\"v=FORSALE1;ftxt=\\226\\156\\168 ...\""  ->  v=FORSALE1;ftxt=✨ ...
// Strip the surrounding quotes, then decode at the byte level (decoding
// character-by-character would mangle multi-byte sequences).
function unquoteTXT(raw) {
  const structural = raw
    .trim()
    .replace(/^"|"$/g, "")
    .replace(/"\s+"/g, ""); // multiple concatenated character-strings
  return decodeDNSCharacterString(structural);
}

function decodeDNSCharacterString(str) {
  const encoder = new TextEncoder();
  const bytes = [];
  let i = 0;
  while (i < str.length) {
    if (str[i] === "\\") {
      const maybeDigits = str.slice(i + 1, i + 4);
      if (/^\d{3}$/.test(maybeDigits)) {
        bytes.push(parseInt(maybeDigits, 10) & 0xff);
        i += 4;
        continue;
      }
      const next = str[i + 1];
      if (next !== undefined) {
        bytes.push(...encoder.encode(next)); // e.g. \" or \\
        i += 2;
        continue;
      }
    }
    const char = String.fromCodePoint(str.codePointAt(i));
    bytes.push(...encoder.encode(char));
    i += char.length;
  }
  try {
    return new TextDecoder("utf-8", { fatal: false }).decode(new Uint8Array(bytes));
  } catch {
    return str; // fall back to the raw (still-escaped) string if decoding somehow fails
  }
}

function parseForSaleRecord(txt) {
  if (!txt.startsWith(VERSION_TAG)) return null;
  const content = txt.slice(VERSION_TAG.length).trim();
  if (!content) return { tag: null, value: null };

  const match = content.match(/^(fcod|ftxt|furi|fval)=([\s\S]*)$/);
  if (!match) return { tag: null, value: null }; // valid version tag, malformed content
  return { tag: match[1], value: match[2] };
}

// High-level check for one registrable domain: cache lookup, then DoH +
// RFC 10023 parsing, then cache write. Returns:
//   { status: "for-sale" | "not-for-sale", records: [...], checkedAt }
//   { status: "error", error: "message", checkedAt }
// `checkedAt` is a Date.now() timestamp of when the DNS answer behind this
// result was actually fetched — whether that just happened, or it's a
// cache hit from an earlier check within the last CACHE_TTL_MS.
async function checkDomain(domain) {
  const cached = await getCached(domain);
  if (cached) return cached;

  let result;
  try {
    const raw = await lookupTXT(`_for-sale.${domain}`);
    const records = raw.map(parseForSaleRecord).filter((r) => r !== null);
    result = records.length > 0
      ? { status: "for-sale", records: records.filter((r) => r.tag) }
      : { status: "not-for-sale", records: [] };
  } catch (err) {
    result = { status: "error", error: String((err && err.message) || err) };
  }

  const ts = Date.now();
  result.checkedAt = ts;
  await setCached(domain, result, ts);
  return result;
}

async function getCached(domain) {
  const key = `cache:${domain}`;
  const store = await chrome.storage.session.get(key);
  const entry = store[key];
  if (entry && Date.now() - entry.ts < CACHE_TTL_MS) return entry.result;
  return null;
}

async function setCached(domain, result, ts) {
  const key = `cache:${domain}`;
  await chrome.storage.session.set({ [key]: { result, ts } });
}
