// background.js — runs the live check. Listens only to navigation
// *metadata* (chrome.webNavigation) for the top-level frame: the URL a tab
// navigates to. It never touches page content, cookies, form data, or
// anything else — that's the whole point of using webNavigation instead of
// a content script or the broader "tabs"/"webRequest" permissions.
//
// Redirect handling: chrome.webNavigation has no per-hop redirect event
// (there is no "onBeforeRedirect" on this API — that name exists on the
// much heavier chrome.webRequest API instead, which needs a "webRequest"
// permission plus host access to the sites being observed, and would
// contradict the "just the visited URL" design goal). What webNavigation
// *does* give us is onBeforeNavigate (the URL the tab starts navigating
// to), onCommitted (the URL it actually lands on, with a
// transitionQualifiers flag when a redirect occurred), and — for
// navigations that fail outright, e.g. a timeout — onErrorOccurred (the
// URL it was trying to reach). So a redirect/failure chain here is always
// exactly two points — where the navigation started, and where it ended
// or gave up — not every intermediate hop. For the common case this
// asks about (example.nl -> example.org) that's exactly what's needed.
//
// Note on the permission warning: Chrome labels webNavigation as
// "Read your browsing history" in the install prompt, because it does let
// an extension observe every URL navigated to, on every site — regardless
// of host_permissions. That warning is broader-sounding than what this
// extension actually does with the data (a same-request domain lookup,
// nothing stored beyond a short-lived per-tab cache), but there's no
// narrower Chrome API for "URL of the current navigation only". Worth
// disclosing plainly in the Web Store listing's permission justification.

importScripts("libs/psl.js", "shared.js");

// tabId -> the URL the current top-level navigation started from.
// In-memory only: if the service worker is terminated mid-navigation
// (Chrome may do this after ~30s idle), the start URL for that one
// in-flight navigation is lost and only the final onCommitted URL gets
// checked. Not persisted to disk.
const pendingStart = new Map();

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return; // ignore iframes/subframes entirely
  pendingStart.set(details.tabId, details.url);
});

chrome.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId !== 0) return;
  dispatchCheck(details.tabId, details.url);
});

// Fires when a navigation fails outright — timeouts, DNS errors at the
// browser level, connection refused, etc. The page never loads, so
// onCommitted never fires either, but the domain itself can still very
// much have a _for-sale record: that's a DNS question, independent of
// whether the site's web server is reachable at all. Without this
// listener, the lamp would just keep showing whatever the previous page's
// state was.
chrome.webNavigation.onErrorOccurred.addListener((details) => {
  if (details.frameId !== 0) return;
  dispatchCheck(details.tabId, details.url);
});

function dispatchCheck(tabId, url) {
  const startUrl = pendingStart.get(tabId);
  pendingStart.delete(tabId);

  const urlChain = startUrl && startUrl !== url ? [startUrl, url] : [url];
  handleNavigation(tabId, urlChain).catch(() => {
    // Swallow: a failed check for one navigation shouldn't crash the
    // worker or block future navigations.
  });
}

chrome.tabs.onRemoved.addListener((tabId) => {
  pendingStart.delete(tabId);
  chrome.storage.session.remove(`tab:${tabId}`);
});

async function handleNavigation(tabId, urlChain) {
  const domains = uniqueRegistrableDomains(urlChain, MAX_CHAIN_DOMAINS);

  if (domains.length === 0) {
    await chrome.storage.session.remove(`tab:${tabId}`);
    setLamp(tabId, "neutral");
    return;
  }

  const results = await Promise.all(
    domains.map(async (domain) => ({ domain, ...(await checkDomain(domain)) }))
  );

  await chrome.storage.session.set({
    [`tab:${tabId}`]: { finalUrl: urlChain[urlChain.length - 1], results, checkedAt: Date.now() },
  });

  // The toolbar "lamp" reflects the whole chain, not just the domain
  // currently being viewed: if a redirect passed through a domain that's
  // for sale (e.g. everyone.eu -> every.one), that's exactly the kind of
  // thing worth flagging even though it's not the domain in the address
  // bar anymore. "for-sale" wins if any hop is for sale; otherwise
  // "error" if any hop's check failed; otherwise "not-for-sale".
  const anyForSale = results.some((r) => r.status === "for-sale");
  const anyError = results.some((r) => r.status === "error");
  setLamp(tabId, anyForSale ? "for-sale" : anyError ? "error" : "not-for-sale");
}

const LAMP_ICONS = {
  neutral: { 16: "icons/lamp-neutral-16.png", 32: "icons/lamp-neutral-32.png", 48: "icons/lamp-neutral-48.png" },
  "not-for-sale": { 16: "icons/lamp-blue-16.png", 32: "icons/lamp-blue-32.png", 48: "icons/lamp-blue-48.png" },
  "for-sale": { 16: "icons/lamp-brightgreen-16.png", 32: "icons/lamp-brightgreen-32.png", 48: "icons/lamp-brightgreen-48.png" },
  error: { 16: "icons/lamp-red-16.png", 32: "icons/lamp-red-32.png", 48: "icons/lamp-red-48.png" },
};

function setLamp(tabId, state) {
  chrome.action.setIcon({ tabId, path: LAMP_ICONS[state] || LAMP_ICONS.neutral });
}

// Walks the (at most 2-entry) chain of URLs from one navigation, resolves
// each to a registrable domain via PSL, and returns the unique ones in
// order (source domain first, final domain last), capped at `limit`.
function uniqueRegistrableDomains(urlChain, limit) {
  const seen = new Set();
  const domains = [];
  for (const url of urlChain) {
    let hostname;
    try {
      hostname = new URL(url).hostname.toLowerCase();
    } catch {
      continue; // non-http(s) URL (chrome://, about:, etc.)
    }
    const domain = getRegistrableDomain(hostname);
    if (!domain || seen.has(domain)) continue;
    seen.add(domain);
    domains.push(domain);
    if (domains.length >= limit) break;
  }
  return domains;
}
