// popup.js — renders the result when the user clicks the extension icon.
//
// Primary path: read the result the background service worker already
// computed for this tab's current navigation (chrome.storage.session,
// written by background.js). This is what makes the popup open instantly
// with no extra network request in the common case.
//
// Fallback path: if there's no stored result yet (e.g. the service worker
// was cold and missed this navigation, or the extension was just
// installed/reloaded on an already-open tab), do a one-off check for the
// current tab's domain using the same shared logic. This only ever needs
// `activeTab`, which is granted for the single tab the user just clicked
// into — no standing access to other tabs or sites.

const els = {
  chain: document.getElementById("chain"),
  details: document.getElementById("details"),
  cacheNote: document.getElementById("cacheNote"),
};

init().catch((err) => renderMessage(String((err && err.message) || err), "error"));

async function init() {
  const tab = await getActiveTab();
  const hostname = hostnameFromTab(tab);

  if (!hostname) {
    renderMessage("This page doesn't have a regular hostname (e.g. an internal browser page).", "error");
    return;
  }

  const key = `tab:${tab.id}`;
  const stored = (await chrome.storage.session.get(key))[key];

  let results;

  if (stored && stored.results && stored.results.length && matchesCurrentPage(stored, hostname)) {
    results = stored.results;
  } else {
    const domain = getRegistrableDomain(hostname);
    if (!domain) {
      renderMessage(
        `Can't determine a registrable domain for "${hostname}" (IP address, localhost, or unlisted TLD).`,
        "error"
      );
      return;
    }
    results = [{ domain, ...(await checkDomain(domain)) }];
  }

  render(results);

  const current = results[results.length - 1];
  els.cacheNote.textContent = current.checkedAt ? `checked ${formatRelativeTime(current.checkedAt)}` : "";
}

function formatRelativeTime(ts) {
  const diffSec = Math.round((Date.now() - ts) / 1000);
  if (diffSec < 10) return "just now";
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.round(diffSec / 60);
  if (diffMin < 60) return `${diffMin} min ago`;
  const diffHour = Math.round(diffMin / 60);
  return `${diffHour}h ago`;
}

// The stored record is for whichever navigation last completed on this
// tab. If the tab has since navigated again (same-document / client-side
// routing, which webNavigation.onCommitted doesn't always catch the same
// way) this loosely confirms the stored data is still about this page.
function matchesCurrentPage(stored, currentHostname) {
  try {
    return new URL(stored.finalUrl).hostname.toLowerCase() === currentHostname;
  } catch {
    return false;
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function hostnameFromTab(tab) {
  if (!tab || !tab.url) return null;
  try {
    const url = new URL(tab.url);
    if (!/^https?:$/.test(url.protocol)) return null; // chrome://, file://, etc.
    return url.hostname.toLowerCase();
  } catch {
    return null;
  }
}

function render(results) {
  els.chain.innerHTML = "";
  els.details.innerHTML = "";
  els.details.hidden = true;

  results.forEach((r, i) => {
    if (i > 0) {
      const arrow = document.createElement("span");
      arrow.className = "arrow";
      arrow.textContent = "→";
      els.chain.appendChild(arrow);
    }
    els.chain.appendChild(renderHop(r));
  });

  const forSale = results.filter((r) => r.status === "for-sale" && r.records && r.records.length);
  if (forSale.length === 0) return;

  els.details.hidden = false;
  const showGroupLabels = forSale.length > 1;

  for (const r of forSale) {
    if (showGroupLabels) {
      const label = document.createElement("div");
      label.className = "group-label";
      label.textContent = r.domain;
      els.details.appendChild(label);
    }
    for (const { tag, value } of r.records) {
      const dt = document.createElement("dt");
      dt.textContent = KNOWN_TAGS[tag] || tag;
      const dd = document.createElement("dd");
      if (tag === "furi" && /^https?:|^mailto:|^tel:/.test(value)) {
        const a = document.createElement("a");
        a.href = value;
        a.textContent = value;
        a.target = "_blank";
        a.rel = "noopener";
        dd.appendChild(a);
      } else {
        dd.textContent = value;
      }
      els.details.appendChild(dt);
      els.details.appendChild(dd);
    }
  }
}

function renderHop(r) {
  const hop = document.createElement("div");
  hop.className = `hop state-${r.status}`;

  const domain = document.createElement("span");
  domain.className = "domain";
  domain.textContent = r.domain;
  hop.appendChild(domain);

  const badge = document.createElement("span");
  badge.className = "badge";
  badge.textContent =
    r.status === "for-sale" ? "For sale" : r.status === "not-for-sale" ? "Not listed" : "Error";
  hop.appendChild(badge);

  return hop;
}

function renderMessage(message, state) {
  els.chain.innerHTML = "";
  const hop = document.createElement("div");
  hop.className = `hop state-${state}`;
  const text = document.createElement("span");
  text.className = "domain";
  text.textContent = message;
  hop.appendChild(text);
  els.chain.appendChild(hop);
  els.details.hidden = true;
}
